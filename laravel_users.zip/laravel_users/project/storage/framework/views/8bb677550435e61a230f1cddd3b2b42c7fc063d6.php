<?php echo e($slot); ?>

<?php /**PATH /Applications/MAMP/htdocs/project/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>